<?php $credentials = "d033e22ae348aeb5660fc2140aec35850c4da997";
